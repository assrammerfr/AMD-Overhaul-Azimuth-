# Azimuth AMD Fix

D3D12 proxy that fixes the stutter/lag on AMD cards in Azimuth.

## What it does
Caches pipeline states so AMD doesn't recompile shaders every time. That's what was killing FPS.

## Install
1. Copy `d3d12.dll` into your Azimuth folder (next to `azimuth.exe`)
2. Launch Azimuth like normal
3. Done

## Uninstall
Delete `d3d12.dll` from the Azimuth folder. That's it.

## What to expect
- Loading screens: way faster (no more shader compile stutter)
- In-game: small FPS boost, less stutter
- It won't make a 5700 XT beat a 3070. It's a workaround, not magic.

## Tested on
- RX 5700 XT: 22 FPS -> 25 FPS in-game, 56 FPS in menus (was 22)
- Should help any AMD RDNA card

## How it works
Azimuth calls D3D12CreateDevice -> proxy intercepts -> wraps the device -> caches PSOs by hash -> returns cached instead of recompiling.

The proxy forwards everything else to the real system d3d12.dll. No game files touched.

## Source
Built from scratch. If Azimuth updates and breaks it, delete the dll and you're back to stock.

- Seth
