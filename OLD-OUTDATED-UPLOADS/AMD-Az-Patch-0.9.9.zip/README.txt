AMD Azimuth 0.9.9 Patch
=======================

Drop d3d12.dll into your azimuth-windows (3) folder, next to azimuth.exe.
That's it.

What it does:
- AMD GPU optimizations (async compute, PSO caching tuned for RDNA)
- Should give you a solid FPS bump, especially on AMD cards

What it doesn't do (yet):
- FSR upscaling / frame gen toggles exist in the config but aren't
  implemented yet. They won't do anything. Coming later.

To uninstall: delete d3d12.dll from the Azimuth folder.

Tested on RX 5700 XT. Should work on any AMD card.
