AMD D3D12 proxy for Azimuth - v2.0
====================================

WHAT IT IS
A d3d12.dll that sits between azimuth.exe and the real Windows D3D12. It wraps
the device, caches graphics pipeline states (PSOs), and writes a log next to
the game. It does not touch Present, the swap chain or the queues.

INSTALL
1. Close Azimuth (and FH2 DLC Launcher).
2. Run tools\deploy_proxy.ps1. It copies d3d12.dll next to azimuth.exe.
   If the game is still running, the script stages the build as
   d3d12.next.dll; run the script again after closing the game to swap it in.
3. Start the game. Check amd_opt.log in the game folder for the line
   "proxy v2.0 attached". tools\verify_proxy_dlc.ps1 checks this for you.

WHAT CHANGED FROM v1.1
- Disk-backed pipeline library (new). Graphics PSOs compiled in one run are
  saved to amd_pso_<adapter LUID>.bin in the game folder and loaded on the next
  run, so pipelines that were compiled late in a session (the 0.1-2.9 s misses
  seen during play) are no longer recompiled on every launch. The file is
  written atomically (temp file + rename) when new PSOs are added, at most
  every 5 seconds, and at a clean exit. A PSO added in the last few seconds
  before a crash or kill may not be saved. A blob the driver rejects is
  ignored and the library starts empty.
- Stable PSO keys. The v1.1 key hashed the root-signature pointer, which
  changes every run, so nothing could hit across runs. Root signatures are now
  keyed by a hash of their serialized content (recorded in
  CreateRootSignature). Same content gives the same key in every process.
  A PSO whose root signature was not created through the proxy stays in
  memory only.
- Stream PSO cache (ID3D12Device2::CreatePipelineState). Hashed by content
  with the pointer-valued subobjects (shaders, root signature, input layout)
  handled by value. Azimuth does not use this path in the 0.9.7 builds
  checked so far, so it has no effect there yet.
- Final stats are printed from DllMain before the log closes, and a periodic
  stats line is written every 512 PSO lookups. Log line names:
    [PSO lib]    library load / store / flush status
    [PSO final]  lookups, hits, libHits (loaded from disk), misses, hit rates
    [PSO stream] stream-cache counters
- Version banner is now v2.0 (the tools scripts check for it).

NOT CHANGED IN v2.0 (and why)
- Descriptor heaps (1M-entry shader-visible heap). No profile was taken, so it
  is left as is.
- Command allocator pool. Not profiled; left as is.
- Resource barrier batching. Still off by default. Wrapping command queues and
  lists crashed IDXGISwapChain::Present (DXGI keeps the real queue pointer), so
  it stays behind AMD_WRAP_COMMAND_OBJECTS (0 by default).
- Texture detiler thread group size (64) and the Tier 3 requirement. Untouched.
- Ordinal exports (d3d12.def). Untouched.
- XAudio2. Deferred to v2.1: Azimuth's GetProcAddress interception needs its
  own reverse-engineering pass before a real replacement is safe.

TESTING STATUS
- Built clean; smoke test passes cold and warm (exit 0). A warm run loads the
  library from disk with 0 misses.
- Not yet tested in gameplay. Pending: RX 5700 XT (Seth) and RX 9070 XT (Nik).
  Compare 1% lows before and after; the proxy targets stutter, not average FPS.

KNOWN LIMITS
- Compute PSOs are not cached (forwarded unchanged).
- The library is per GPU (LUID). Driver or game updates that change shader
  bytecode produce new keys; old entries stay in the file until it is deleted.
  Deleting amd_pso_*.bin is always safe and forces a fresh compile.
- Azimuth's PSO files and this library are independent; this proxy never reads
  pipelines-<vendor>-<device>.bin.
